using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TaskManagementWeb.Components.Pages
{
    public class _HostModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
